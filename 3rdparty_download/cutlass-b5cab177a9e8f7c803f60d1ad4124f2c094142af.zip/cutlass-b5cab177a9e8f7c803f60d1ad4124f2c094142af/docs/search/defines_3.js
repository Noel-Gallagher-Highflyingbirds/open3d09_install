var searchData=
[
  ['static_5fassert',['static_assert',['../platform_8h.html#adde4c9ea91b753491851361a4198c009',1,'platform.h']]]
];
