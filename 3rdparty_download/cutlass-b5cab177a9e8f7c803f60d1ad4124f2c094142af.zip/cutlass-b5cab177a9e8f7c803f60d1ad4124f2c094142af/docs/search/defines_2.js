var searchData=
[
  ['noexcept',['noexcept',['../platform_8h.html#a189faadd7f99f6c354db09acbb2aafcd',1,'platform.h']]],
  ['nullptr',['nullptr',['../platform_8h.html#ab979d9d4b4923f7c54d6caa6e1a61936',1,'platform.h']]]
];
