var searchData=
[
  ['_5f_5fnv_5fstd_5fmax',['__NV_STD_MAX',['../platform_8h.html#abd31f291635329bc15292954f1f01d38',1,'platform.h']]],
  ['_5f_5fnv_5fstd_5fmin',['__NV_STD_MIN',['../platform_8h.html#a39e234a3e3b0018b58df720bcb143420',1,'platform.h']]],
  ['_5f_5fplatform_5fcat',['__platform_cat',['../platform_8h.html#aece7fe71be5aaf8d12dc9e2372f97de4',1,'platform.h']]],
  ['_5f_5fplatform_5fcat_5f',['__platform_cat_',['../platform_8h.html#acd148999a5caeba8f6fd52e7e288e659',1,'platform.h']]]
];
