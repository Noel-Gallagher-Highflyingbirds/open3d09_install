## Licenses

* picojson : BSD license.
* ImGui : The MIT license. Copyright (c) 2014-2015 Omar Cornut and ImGui contributors.
* ImGuizmo : The MIT license. (`imgui/ImGuizmo.LICENSE`)
* bt3gui : zlib license. 
* nativefiledialog : The MIT license. (`nativefiledialog/LICENSE`)
* glew : BSD/MIT license.
* tinyobjloader : MIT license.
* tinyexr : BSD license.
* glm : Happy Bunny license(modified MIT).
